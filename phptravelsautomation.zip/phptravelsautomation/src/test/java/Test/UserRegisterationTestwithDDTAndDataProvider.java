package Test;

import Pages.HomePage;
import Pages.UserRegisterationPage;
import com.ahmed.excelizer.ExcelReader;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class UserRegisterationTestwithDDTAndDataProvider extends TestBase {

    HomePage homeobject;
    UserRegisterationPage registerobject;



    public String filepath = System.getProperty("user.dir")+"//excel//data.xlsx";

    @DataProvider(name = "UserData")
    public Object[][] UserData() {
        return ExcelReader.loadTestData(filepath, "Sheet1");
    }



    @Test(dataProvider = "UserData")
    public void usercanregistersuccessfully(String firstname,String lastname,String email,String phonenumer,String streetaddress1,String streetaddress2,String city,String pass, String watsnum,String actual,String expected){
        homeobject = new HomePage(driver);
        homeobject.openregisterationpage();
        registerobject = new UserRegisterationPage(driver);
        registerobject.userregisteration(firstname,lastname,email,phonenumer,streetaddress1,streetaddress2,city,pass,watsnum);

    }
}
