package Test;

import Pages.HomePage;
import Pages.PageBase;
import Pages.UserLogin;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.DataProvider;

public class UserLoginTestwithDDT extends PageBase {
    public UserLoginTestwithDDT(WebDriver driver) {
        super(driver);
    }


    HomePage homeobject;
    UserLogin userloginobject;

    public String filepath = System.getProperty("user.dir")+"//excel//data.xlsx";

    @DataProvider(name = "usercredentials")
    public Object[][] usercredentials() {
        return com.ahmed.excelizer.ExcelReader.loadTestData(filepath, "Sheet2");
    }


    @Test
    public void usercanloginsuccessfully(String email,String password){
        homeobject = new HomePage(driver);
        homeobject.openLoginPage();
        userloginobject = new UserLogin(driver);
        userloginobject.UserLoginSuccessfully(email,password);

    }
}
