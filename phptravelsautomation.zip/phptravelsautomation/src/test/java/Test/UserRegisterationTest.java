package Test;
import Pages.HomePage;
import Pages.UserRegisterationPage;
import org.testng.annotations.Test;


public class UserRegisterationTest extends TestBase {
    HomePage homeobject;
    UserRegisterationPage registerobject;



    @Test
    public void usercanregistersuccessfully() {
        homeobject = new HomePage(driver);
        homeobject.openregisterationpage();
        registerobject = new UserRegisterationPage(driver);
        registerobject.userregisteration("wessam", "gamal", "wessam.gamal1992@gmail.com", "12345", "giza", "new cairo", "cairo", "666", "123");
    }



}
