package Test;

import Pages.HomePage;
import Pages.UserLogin;
import org.junit.Test;

public class UserLoginTest extends TestBase {
    HomePage homeobject;
    UserLogin userloginobject;

    @Test
    public void usercanloginsuccessfully(){
        homeobject = new HomePage(driver);
        homeobject.openLoginPage();
        userloginobject = new UserLogin(driver);
        userloginobject.UserLoginSuccessfully("wessam.gamal1992@gmail.com","123");

    }
}
