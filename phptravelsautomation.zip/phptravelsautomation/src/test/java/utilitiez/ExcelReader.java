package utilitiez;

import org.testng.annotations.DataProvider;

public class ExcelReader {
    public String filepath = System.getProperty("user.dir")+"//excel//data.xlsx";

    @DataProvider(name = "userdata")
    public Object[][] UserData() {
        return com.ahmed.excelizer.ExcelReader.loadTestData(filepath, "Sheet1");
    }

    @DataProvider(name = "usercredentials")
    public Object[][] Usercredentials() {
        return com.ahmed.excelizer.ExcelReader.loadTestData(filepath, "Sheet2");
    }


}
