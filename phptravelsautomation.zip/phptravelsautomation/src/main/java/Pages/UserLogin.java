package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class UserLogin extends PageBase {

    public UserLogin(WebDriver driver) {
        super(driver);
    }


    @FindBy(id = "inputEmail")
    WebElement EmailAddress;

    @FindBy(id = "inputPassword")
    WebElement Password;

    @FindBy(className = "iCheck-helper")
    WebElement checkbox;

    @FindBy (id = "login")
    WebElement loginBtn;


    public void UserLoginSuccessfully(String email, String pass){
        setTextElementtext(EmailAddress,email);
        setTextElementtext(Password,pass);
        clickButton(checkbox);
        clickButton(loginBtn);
    }
}
