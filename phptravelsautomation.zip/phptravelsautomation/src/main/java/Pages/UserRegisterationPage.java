package Pages;

import org.apache.bcel.generic.Select;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class UserRegisterationPage extends PageBase {

    public UserRegisterationPage(WebDriver driver){
        super(driver);
    }


        @FindBy(id = "inputFirstName")
        WebElement FirstName;

        @FindBy(id = "inputLastName")
        WebElement LastName;

        @FindBy(id = "inputEmail")
        WebElement EmailAddress;

        @FindBy(xpath = "//div[@class='iti-arrow']")
        WebElement dropdownArrow;

        @FindBy(xpath = "//span[contains(text(),'Egypt (\u202Bمصر\u202C\u200E)')]")
        WebElement countrycode;

        @FindBy(xpath = "//input[@id='inputPhone']")
        WebElement PhoneNumber;

        //Billing Address
        @FindBy(xpath = "//input[@id='inputAddress1']")
        WebElement StreetAddress;

        @FindBy(xpath = "//input[@id='inputAddress2']")
        WebElement StreetAddress2;

        @FindBy(id = "inputCity")
        WebElement City;

    @FindBy(xpath = "//select[@id='inputCountry']")
    WebElement country;

        //Additional Required Information

        @FindBy(xpath = "//input[@id='customfield2']")
        WebElement Mobile;

        @FindBy(xpath = "//input[@id='inputNewPassword1']")
        WebElement Passowrd;

        @FindBy(xpath = "//input[@id='inputNewPassword2']")
        WebElement ConfirmPassword;

        @FindBy(xpath = "//div[@class='recaptcha-checkbox-border']")
        WebElement capatcha;

        @FindBy(xpath = "/input[@value='Register']")
        WebElement Register;



    public void userregisteration(String firstname, String lastname, String email, String phonenumber, String stretaddress1, String streetaddress2, String city,String pswd, String watsappnum)
    {
setTextElementtext(FirstName,firstname);
            setTextElementtext(LastName,lastname);
            setTextElementtext(EmailAddress,email);

        clickButton(dropdownArrow);
        clickButton(countrycode);
        setTextElementtext(PhoneNumber,phonenumber);

            setTextElementtext(StreetAddress,stretaddress1);
            setTextElementtext(StreetAddress2,streetaddress2);
            setTextElementtext(City,city);

            //drpcountry.selectByValue("EG");
        setTextElementtext(Mobile,watsappnum);

            setTextElementtext(Passowrd,pswd);
            setTextElementtext(ConfirmPassword,pswd);
            clickButton(capatcha);
            clickButton(Register);
        }
    }







